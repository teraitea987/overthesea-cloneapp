## License

Mattone is available under the SIL Open Font License v1.1

See [OFL.txt](OFL.txt) for more details.

## About Author

Collletttivo

Submit your work using Collletttivo typefaces at collletttivo@gmail.com